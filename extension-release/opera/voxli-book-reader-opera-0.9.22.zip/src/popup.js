import { applyI18n, initI18n, t } from "./i18n.js";
import { STORAGE_KEYS, storageGet } from "./storage.js";

function readerUrl(query = "") {
  const suffix = query ? `?${query}` : "";
  return chrome.runtime.getURL(`reader.html${suffix}`);
}

async function openReader(query = "") {
  await chrome.tabs.create({ url: readerUrl(query) });
  globalThis.close();
}

async function init() {
  await initI18n();
  applyI18n();

  const openBookBtn = document.getElementById("open-book");
  const openLastBtn = document.getElementById("open-last");
  const openSettingsBtn = document.getElementById("open-settings");
  const statusNode = document.getElementById("status");

  openBookBtn.addEventListener("click", () => openReader());
  openLastBtn.addEventListener("click", () => openReader("last=1"));
  openSettingsBtn.addEventListener("click", async () => {
    await chrome.runtime.openOptionsPage();
    globalThis.close();
  });

  try {
    const lastBook = await storageGet(STORAGE_KEYS.lastBook);
    if (lastBook?.title) {
      statusNode.textContent = `${t("lastBook")}: ${lastBook.title}`;
    } else {
      statusNode.textContent = t("statusNoRecentBook");
    }
  } catch {
    statusNode.textContent = t("statusNoRecentBook");
  }
}

await init();
